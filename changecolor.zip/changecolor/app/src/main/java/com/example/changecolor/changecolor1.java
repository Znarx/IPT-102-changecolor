package com.example.changecolor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class changecolor1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_changecolor1);

        Spinner spinner = findViewById(R.id.spinner);
        ConstraintLayout constraintLayout = findViewById(R.id.linear);

        String[] colors = {"Blue", "Green", "Red", "Yellow", "White", "Black", "Pink"};
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, colors);
        spinner.setAdapter(arrayAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        constraintLayout.setBackgroundColor(Color.parseColor("#FF032DFF"));
                        break;
                    case 1:
                        constraintLayout.setBackgroundColor(Color.parseColor("#FF09DF12"));
                        break;
                    case 2:
                        constraintLayout.setBackgroundColor(Color.parseColor("#FFFB0404"));
                        break;
                    case 3:
                        constraintLayout.setBackgroundColor(Color.parseColor("#FFFFEB3B"));
                        break;
                    case 4:
                        constraintLayout.setBackgroundColor(Color.parseColor("#FFFFFFFF"));
                        break;
                    case 5:
                        constraintLayout.setBackgroundColor(Color.parseColor("#FF000000"));
                        break;
                    case 6:
                        constraintLayout.setBackgroundColor(Color.parseColor("#FFCF0663"));
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
